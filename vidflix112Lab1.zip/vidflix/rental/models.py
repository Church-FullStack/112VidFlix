from django.db import models
from django.utils import timezone

# Create your models here.

class Genre(models.Model):
    name = models.CharField(max_length=256)
    
class Movie(models.Model):
    title = models.CharField(max_length=256)
    release_year = models.IntegerField()
    in_stock = models.IntegerField()
    price  = models.FloatField()
    image_url = models.CharField(max_length=999)
    genre = models.ForeignKey(Genre, on_delete=models.CASCADE)
    runtime = models.IntegerField()
    date_created = models.DateTimeField(default=timezone.now)