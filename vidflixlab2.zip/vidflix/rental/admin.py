from django.contrib import admin
from .models import Movie, Genre

# Register your models here.
class MovieTemplate(admin.ModelAdmin):
    list_display = ("id","release_year","title","genre", "in_stock", "price")
    list_display_links = ("id", "title")

class GenreTemplate(admin.ModelAdmin):
    list_display = ("id", "name")
    list_display_links = ("id", "name")

admin.site.register(Movie, MovieTemplate)
admin.site.register(Genre, GenreTemplate)
