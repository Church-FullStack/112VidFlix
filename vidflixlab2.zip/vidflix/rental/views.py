from django.shortcuts import render
from django.http import HttpResponse
from .models import Movie, Genre

# Create your views here.

def home(request):
    all_movies = Movie.objects.all()
    return render(request, "index.html", {'title': 'Server Side Render', 'movies': all_movies})
def about(request):
    return render(request, "about.html")